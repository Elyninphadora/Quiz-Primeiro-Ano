# Pacote reconstruído
Arquivos prontos para uso.